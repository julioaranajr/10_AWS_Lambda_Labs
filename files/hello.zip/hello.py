def lambda_handler(event, context):
    print(context.function_name)
    print("Hello World, from Talent-Academy Lambda Test")
